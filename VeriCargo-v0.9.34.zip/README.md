# VeriCargo Chrome Extension

This folder contains the Manifest V3 side-panel extension for the Cloud Run-backed VeriCargo Gmail workflow. It has one data path: a user authorizes Gmail through the VeriCargo Cloud Run service, Cloud Run imports Inbox messages, and the extension reads the imported records through an authenticated session.

No sample inbox, mock cases, direct Gmail API token handling, or Demo mode is included.

## Load it in Chrome

1. Open `chrome://extensions`.
2. Turn on **Developer mode**.
3. Select **Load unpacked**.
4. Choose this `chrome-extension` folder.
5. Pin the extension and open its side panel.
6. Select **Connect Gmail** and complete Google authorization in the tab that opens.
7. Return to the side panel. It imports the Inbox through Cloud Run in resumable batches.
8. After email classification completes, document processing starts automatically. Results appear
   progressively in the two green review queues or in **SI/BL Document Comparison**.

## Architecture

- `manifest.json` permits access only to the VeriCargo Cloud Run origin.
- `cloud-client.js` manages the Cloud Run connection attempt, extension session, synchronization,
  email classification, and progressive document-processing requests.
- `sidepanel.js` renders Inbox Summary, My Cases, the two document-review queues, and the side-by-side
  seven-field SI/BL comparison.
- Human-review states use red alert styling. **View Email in Gmail** opens the selected message in
  the original Gmail tab instead of creating a new tab.
- Cloud Run automatically creates and applies top-level category labels such as
  `Document Comparison` and `Email Intent Uncertain` after classification. The spam category uses
  `Spam Email` because Gmail reserves the system label name `Spam`. It migrates the old
  nested and `VeriCargo - <category>` labels, removes obsolete category labels, and retains the
  Gmail `INBOX` label.
- The My Cases email list stays in a fixed-height panel with its own scrollbar.
- Refresh imports new Inbox messages and automatically runs classification, Gmail label syncing,
  and document processing. Manual classification is only exposed as a retry after an AI error.
- `service-worker.js` opens the side panel when the toolbar action is selected.

Google OAuth credentials and Gmail refresh tokens are not stored in this extension. The OAuth client secret is mounted into Cloud Run from Secret Manager, and refresh tokens are encrypted before Firestore storage.

## Development

After editing extension files, return to `chrome://extensions` and select **Reload** on the extension card.
